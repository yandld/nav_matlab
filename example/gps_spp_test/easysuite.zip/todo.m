%+ easy11 bbbbbbbbbb
% easy12 chistart
% easy14 bound2
%+ easy17 bbbbbbbbbb
% 
% 
% bbbbbbbbb rinexa: bbbbbbbbbbbbbbbbbbb in the end