%%========================================
%%     Toolbox for attitude determination
%%     Zhen Dai
%%     dai@zess.uni-siegen.de
%%     ZESS, University of Siegen, Germany
%%     Last Modified  : 1.Sep.2008
%%========================================
%% Functions:
%%       Show the calculated yaw, roll and pitch
%% Input parameters:     
%%      mAttitudeRecordCalculated -> Matrix having the attitude parameters
%%      at each epoch.
%%      title_str -> Title shown in the figure
%% Output:
%%      Figure

function DrawAttitudeFigure(mAttitudeRecordCalculated,title_str) 
 
totalepoch=length(mAttitudeRecordCalculated); 
tn=1:totalepoch;
scale_Y=5;

for i=1:1:3, 
    vMean(i)=mean(mAttitudeRecordCalculated(:,i));
    vStd(i)=std(mAttitudeRecordCalculated(:,i));
    vMaxVal(i)=max(mAttitudeRecordCalculated(:,i));
    vMinVal(i)=min(mAttitudeRecordCalculated(:,i));
end

figure; 
set(gcf,'MenuBar','none','NumberTitle','off','Name',title_str);
movegui(gcf,'center');

for i=1:1:3,
 
    if i==1, subplot(311); end %% YAW
    if i==2, subplot(312); end %% PITCH
    if i==3, subplot(313); end %% ROLL 
 
    upper_limit=vMaxVal(i);
    lower_limit=vMinVal(i);
    range=upper_limit-lower_limit;
    step_Y=range/(scale_Y-1);
    vYTick=[lower_limit:step_Y:upper_limit];
    for j=1:1:scale_Y,
        vYTickLabel{j}=sprintf('%4.2f',vYTick(j));
    end
    sTitle=sprintf('Mean=%4.4f Std=%4.4f',vMean(i),vStd(i));
    plot(tn,mAttitudeRecordCalculated(tn,i),'b','LineWidth',2);
    hold on 
    title(sTitle)
    set(gca,'YTick',vYTick);
    set(gca,'YTickLabel',vYTickLabel);
    set(gca,'YGrid','on')
    axis([1 totalepoch lower_limit upper_limit])
    grid on
    if i==1,  ylabel('Yaw [deg]'); end %% YAW
    if i==2,  ylabel('Pitch [deg]'); end %% PITCH
    if i==3,  ylabel('Roll [deg]'); end %% ROLL
    xlabel('Epoch')
end
hold off
 