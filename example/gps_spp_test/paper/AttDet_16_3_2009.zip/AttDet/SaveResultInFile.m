%%========================================
%%     Toolbox for attitude determination
%%     Zhen Dai
%%     dai@zess.uni-siegen.de
%%     ZESS, University of Siegen, Germany
%%     Last Modified  : 1.Sep.2008
%%========================================
%% Functions:
%%      Save the attitude result into a data file
%% Input parameters:
%%     mAttitude -> attitude parameters of each epoch
%%     mEpochStr -> epoch expressed in STRING
%%     title_str -> title of the result
%%     filename -> name of the file to be written
%% Output:
%%       Saved in a data file 

function SaveResultInFile(mAttitude,mEpochStr, title_str,filename)
 
totalepoch=size(mAttitude,1);
fid=fopen(filename,'at');
fprintf(fid,'\n%s\n\n',title_str);
for epoch=1:1:totalepoch,
    epoch_str=mEpochStr{epoch};
    str=sprintf('At Epoch %s -> YAW=%3.3f  ROLL=%3.3f  PITCH=%3.3f', ...
        epoch_str, mAttitude(epoch,1),mAttitude(epoch,2),mAttitude(epoch,3));
    fprintf(fid,'%s\n',str); 
end
fclose(fid);