%%========================================
%%     Toolbox for attitude determination
%%     Zhen Dai
%%     dai@zess.uni-siegen.de
%%     ZESS, University of Siegen, Germany
%%     Last Modified  : 1.Sep.2008
%%========================================
%% Functions:
%%      Display the magnitude of 3D baseline error
%% Input parameters:     
%%      vBaselineErr-> Vector of baseline errors
%%      title_str -> Title shown in the figure

function  DisplayBaselineErr(vBaselineErr,title_str) 

totaldata=length(vBaselineErr);
x=1:totaldata;
 
figure;
set(gcf,'MenuBar','none','NumberTitle','off','Name',title_str);
movegui(gcf,'center');
plot(x,vBaselineErr(x),'b');
xlabel('Epoch')
ylabel('Magnitude of baseline error [m] ')
grid on
hold off

