%%========================================
%%     Toolbox for attitude determination
%%     Zhen Dai
%%     dai@zess.uni-siegen.de
%%     ZESS, University of Siegen, Germany
%%     Last Modified  : 1.Sep.2008
%%========================================
%% Functions:
%%      Read the RINEX navigation file and save it into a internal matrix
%% Input parameters:
%%      NavFileName --> RINEX navigation file name
%% Output:
%%      mEphTime -> Time of each ephemerides paragraph in "seconds of week"
%%      mEphemerides -> Ephemerides parameters.   
%%  Remarks:
%%      1. The matrix mEphemerides is a 3-D matrix. The 1st order reflects the
%%      satellite PRN. The 2nd order denotes the ephemerides epochs (about
%%      2 hours interval). the 3rd order is the index of the parameters
%%      which are defined internally.
%%      2. The output is saved in the data file named "RinexNav".


function LoadRinexNav(NavFileName)

%% Open the navigation file
fid=fopen(NavFileName);
if fid==-1,
    error ('Cannot open this file!!!')
end

totalGPSsatellite=32;
clear  mEphTime mEphemerides vSatTotalRec mTime

while (1)
    %% ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    %%                  Check the head section
    %% ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    line80 = GetLine80(fid);
    if findstr(line80,'END OF HEADER'),
        break;
    end
    if findstr(line80,'ION ALPHA'),
        ALPHA(1) = str2num(line80(3:14));
        ALPHA(2) = str2num(line80(15:26));
        ALPHA(3) = str2num(line80(27:38));
        ALPHA(4) = str2num(line80(39:50));
    end
    if findstr(line80,'ION BETA'),
        BETA(1) = str2num(line80(3:14));
        BETA(2) = str2num(line80(15:26));
        BETA(3) = str2num(line80(27:38));
        BETA(4) = str2num(line80(39:50));
    end
    if findstr(line80,'DELTA-UTC'),
        UTC_A0 = str2num(line80(4:23));
        UTC_A1 = str2num(line80(24:42));
        UTC_TOT = str2num(line80(43:51));
        UTC_WN = str2num(line80(52:60));
    end
    if findstr(line80,'LEAP SECONDS'),
        LEAP_SEC = str2num(line80(1:6));
    end
end
%
%  Initialize vector of Satellite ID's
vSatTotalRec(1:totalGPSsatellite) = 0;
%  Loop through the file
while (1)
    %% ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    %%         Read each ephemerides paragraph
    %% ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    line80 = GetLine80(fid);

    if line80(1)==-1, break, end
    %% Satellite PRN
    satID = str2num(line80(1:2));
    rec=vSatTotalRec(satID); %% Used for saving the data  into matrix
    %% Get the ephemerides epoch
    year = str2num(line80(4:5));
    month = str2num(line80(7:8));
    day= str2num(line80(10:11));
    hour = str2num(line80(13:14));
    minute = str2num(line80(16:17));
    second = str2num(line80(18:22));
    [gps_week,sec_of_week]=GetWeekSeconds(year, month ,day, hour, minute, second);
    %% If the deviation between the adjacent ephemerides of a
    %% satellite are lager than 1000s, we then consider  that a new
    %% ephemerides reflecting the next 2 hours is coming. for example, 
    %% one ephemerides is on17:59 and the other on 18:00
    %% than we use the latter one and we consider they represent the same
    %% ephemerides epoch.
    if (rec>=1) ,
        if (abs(sec_of_week-mTime(satID,rec))<1000),
            rec=rec-1; %% erase the old one
        end
    end
    rec=rec+1;
    %% vSatTotalRec reflects how many ephemerides for a certain satellite
    %% are saved.
    vSatTotalRec(satID)=rec;
    %% mTime has the ephemerides epoch
    mTime(satID,rec)=sec_of_week;
    %% Parameters related to satellite clock correction
    clockbias = str2num(line80(23:41));
    clockdrift = str2num(line80(42:60));
    clockdriftrate= str2num(line80(61:79));
    %% Read ephemerides parameters one by one
    line80 = GetLine80(fid);
    IODE  = str2num(line80(4:22));
    Crs  = str2num(line80(23:41));
    Delta_n = str2num(line80(42:60));
    M0 = str2num(line80(61:79));

    line80 = GetLine80(fid);
    Cuc = str2num(line80(4:22));
    e = str2num(line80(23:41));
    Cus = str2num(line80(42:60));
    sqrt_A = str2num(line80(61:79));

    line80 = GetLine80(fid);
    TOE = str2num(line80(4:22));
    Cic= str2num(line80(23:41));
    OMEGA = str2num(line80(42:60));
    CIS = str2num(line80(61:79));

    line80 = GetLine80(fid);
    i0= str2num(line80(4:22));
    Crc = str2num(line80(23:41));
    omega = str2num(line80(42:60));
    OMEGA_DOT= str2num(line80(61:79));

    line80 = GetLine80(fid);
    IDOT = str2num(line80(4:22));
    code_l2= str2num(line80(23:41));
    gps_week = str2num(line80(42:60));
    l2_p_data = str2num(line80(61:79));

    line80 = GetLine80(fid);
    sv_accuracy= str2num(line80(4:22));
    sv_health = str2num(line80(23:41));
    TGD= str2num(line80(42:60));
    IODC = str2num(line80(61:79));

    line80 = GetLine80(fid);
    trans_time_message = str2num(line80(4:22));
    spare1 = str2num(line80(23:41));
    spare2 = str2num(line80(42:60));
    spare3 = str2num(line80(61:79));

    %% Put the ephemerides parameters into a matrix
    mEphemerides(satID,rec,1)=satID;
    mEphemerides(satID,rec,2)=sec_of_week; %% Time: Seconds of week
    mEphemerides(satID,rec,3)=clockbias;
    mEphemerides(satID,rec,4)=clockdrift;
    mEphemerides(satID,rec,5)=clockdriftrate;
    mEphemerides(satID,rec,6)=IODE;
    mEphemerides(satID,rec,7)=Crs;
    mEphemerides(satID,rec,8)=Delta_n;
    mEphemerides(satID,rec,9)=M0;
    mEphemerides(satID,rec,10)=Cuc;
    mEphemerides(satID,rec,11)=e;
    mEphemerides(satID,rec,12)=Cus;
    mEphemerides(satID,rec,13)=sqrt_A;
    mEphemerides(satID,rec,14)=TOE;
    mEphemerides(satID,rec,15)=Cic;
    mEphemerides(satID,rec,16)=OMEGA;
    mEphemerides(satID,rec,17)=CIS;
    mEphemerides(satID,rec,18)=i0;
    mEphemerides(satID,rec,19)=Crc;
    mEphemerides(satID,rec,20)=omega;
    mEphemerides(satID,rec,21)=OMEGA_DOT;
    mEphemerides(satID,rec,22)=IDOT;
    mEphemerides(satID,rec,23)=code_l2;
    mEphemerides(satID,rec,24)=gps_week;
    mEphemerides(satID,rec,25)=l2_p_data;
    mEphemerides(satID,rec,26)=sv_accuracy;
    mEphemerides(satID,rec,27)=sv_health;
    mEphemerides(satID,rec,28)=TGD;
    mEphemerides(satID,rec,29)=IODC;
    mEphemerides(satID,rec,30)=trans_time_message;
    %% The time of each ephemerides
    mEphTime(satID,rec)=sec_of_week;
end
 %% Sate the ephemerides parameters into a matrix
save('RinexNav','mEphTime','mEphemerides' )
