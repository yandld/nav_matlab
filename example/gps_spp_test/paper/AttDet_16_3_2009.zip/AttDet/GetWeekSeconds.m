%%========================================
%%     Toolbox for attitude determination
%%     Zhen Dai
%%     dai@zess.uni-siegen.de
%%     ZESS, University of Siegen, Germany
%%     Last Modified  : 1.Sep.2008
%%========================================
%% Functions:
%%     Convert YMDHMS time to "GPS week"+"Seconds of week"
%% Input parameters:
%%     YMDHMS time parameters. Except for the second, the other must be
%%     given in integer. 
%% Output:
%%     gps_week -> GPS week 
%%     sec_of_week -> seconds of week        
%% Remarks:
%%      It may provide some float results when processing the interger
%%      "Second" due to the approximation in the calculation. A corresponding final
%%      test is made.
%%  References:
%%      B.Hofmann-Wellenhof, H.Lichtenegger and J.Collins: GPS Theory
%%      and practice. 2001. Fifth revised edition. Springer, Wien, New York.
%%      pp.37-38.

function [gps_week,sec_of_week]=GetWeekSeconds(year, month ,day, hour, minute, second)
%% First calculate Julian date
if month <= 2,
    year = year-1;
    month = month+12;
end
%% Solve millennium bugs 
if year> 80,
    year = 1900+year;
else
    year = 2000+year;
end
%% Follow the procedure on P.38
UT=hour+minute/60+second/3600;
iJD=  fix(365.25*(year))+fix(30.6001*(month+1))+day+UT/24+1720981.5;
a = fix(iJD+.5);
b = a+1537;
c = fix((b-122.1)/365.25);
d = fix(365.25*c);
e = fix((b-d)/30.6001);
D= b-d-fix(30.6001*e)+rem(iJD+.5,1);
iN = rem(fix(iJD+.5),7);
gps_week = fix((iJD-2444244.5)/7);
gps_week=rem(gps_week,1024); %% Roll over occurs every 1024 years
sec_of_week = (rem(D,1)+iN+1)*86400;
%%  if the second is integer, then the seconds of week should also be
%%  integer. Drop the unexpected float value resulted from converting
%%  to the "Second in week".
if abs(second-round(second))<1e-3,
    sec_of_week=round(sec_of_week);
end
