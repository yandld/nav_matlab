%%========================================
%%     Toolbox for attitude determination
%%     Zhen Dai
%%     dai@zess.uni-siegen.de
%%     ZESS, University of Siegen, Germany
%%     Last Modified  : 1.Sep.2008
%%========================================
%% Functions:
%%      Implement the earth rotation correction when calculating the
%%      satellite positions
%% Input parameters:     
%%      transit_time -> Time needed from signal transmission to the signal receiption
%%      vSatPosBeforeRotation -> Satellite coordinate in ECEF before earth rotation
%%                                                       correction
%% Output:
%%     vSatXYZ -> Satellite positions in ECEF after earth rotation correction 
%% Remarks:
%%      WGS84 
%%  Reference:
%%      B.Hofmann-Wellenhof, H.Lichtenegger and J.Collins: GPS Theory
%%      and practice. 2001. Fifth revised edition. Springer, Wien, New York.
 

function vSatXYZ=EarthRotation(transit_time,vSatPosBeforeRotation)  
%% Earth rotation rate 
rot_rate = 7.2921151467e-5; 
rot_angle = transit_time*rot_rate; 
%% Rotation matrix
mEarthRotation= [cos(rot_angle) sin(rot_angle) 0;    
                              -sin(rot_angle) cos(rot_angle) 0;
                                      0          0       1];
%% Rotate the coordinate
vSatXYZ = mEarthRotation*vSatPosBeforeRotation;