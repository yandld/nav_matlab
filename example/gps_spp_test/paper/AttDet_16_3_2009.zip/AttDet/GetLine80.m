%%========================================
%%     Toolbox for attitude determination
%%     Zhen Dai
%%     dai@zess.uni-siegen.de
%%     ZESS, University of Siegen, Germany
%%     Last Modified  : 1.Sep.2008
%%========================================
%% Functions:
%%     Read a line from the file. If this line has less than 80 characters,
%%     then use 0000 to append.
%% Input parameters:
%%     fid -> file id.
%% Output:
%%     line -> line with 80 characters  
%% Remarks:
%%      This makes sense in reading of the RINEX OBS and NAV files, as some
%%      lines do not really contain 80 characters although they should have.

function line=GetLine80(fid)

line = fgetl(fid); 
if line==-1,  %% End of file
    return; 
end 
len = length(line);    
if len < 80, line(len+1:80) = '0'; end
end