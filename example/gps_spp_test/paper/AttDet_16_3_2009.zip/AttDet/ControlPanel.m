%%========================================
%%     Toolbox for attitude determination
%%     Zhen Dai
%%     dai@zess.uni-siegen.de
%%     ZESS, University of Siegen, Germany
%%     Last Modified  : 1.Sep.2008
%%========================================

%% GUI


function varargout = ControlPanel(varargin)
% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
    'gui_Singleton',  gui_Singleton, ...
    'gui_OpeningFcn', @ControlPanel_OpeningFcn, ...
    'gui_OutputFcn',  @ControlPanel_OutputFcn, ...
    'gui_LayoutFcn',  [] , ...
    'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% --- Executes just before ControlPanel is made visible.
function ControlPanel_OpeningFcn(hObject, eventdata, handles, varargin)
handles.output = hObject;
guidata(hObject, handles);
movegui(hObject,'center'); %% Put it in the screen center 


% ====================================
%                       Show  user manual
% ====================================  
function pushbutton8_Callback(hObject, eventdata, handles)
% str = computer;
% if strcmp(str,'PCWIN') || strcmp(str,'PCWIN64'),
    open('Readme.pdf');
% else
%     msgbox('Sorry, this function is only valid in Windows system. Please check the Readme.pdf file embedded in the program package.')
% end
% ====================================
%           Loading the RINEX observation file
% ==================================== 
function load_obs_button_Callback(hObject, eventdata, handles)
[fn, path] = uigetfile({'*.*'},'Select a RINEX obervation file');
if fn~=0,
    filename=strcat(path,fn);
    vFileNames=get(handles.listbox1,'String');
    totalfile=length(vFileNames);
    vFileNames{totalfile+1}= filename ;
    set(handles.listbox1,'String',vFileNames);
end

% ====================================
%           Clear all selected files (Reset)
% ==================================== 
function resetbutton_Callback(hObject, eventdata, handles)
set(handles.listbox1,'String',{});
set(handles.text_nav,'String','');
close all
clear all
clc
ControlPanel

% ====================================
%           Loading the RINEX navigation file
% ==================================== 
function load_nav_button_Callback(hObject, eventdata, handles)
[fn, path] = uigetfile({'*.*'},'Select a RINEX navigation file');
if fn~=0,
    filename=strcat(path,fn);
    set(handles.text_nav,'String',filename);
end

% ====================================
%           Process all input parameters
% ==================================== 
function run_button_Callback(hObject, eventdata, handles)
mBaseline=zeros(6,3);
for i=1:1:6,
    for j=1:1:3,
        clear textstr
        if (i==1)&&(j==1), textstr=get(handles.baseline12,'String'); end
        if (i==1)&&(j==2), textstr=get(handles.baseline12,'String'); end
        if (i==1)&&(j==3), textstr=get(handles.baseline12,'String'); end
        if (i==2)&&(j==1), textstr=get(handles.baseline13,'String'); end
        if (i==2)&&(j==2), textstr=get(handles.baseline13,'String'); end
        if (i==2)&&(j==3), textstr=get(handles.baseline13,'String'); end
        if (i==3)&&(j==1), textstr=get(handles.baseline23,'String'); end
        if (i==3)&&(j==2), textstr=get(handles.baseline23,'String'); end
        if (i==3)&&(j==3), textstr=get(handles.baseline23,'String'); end
        if (i==4)&&(j==1), textstr=get(handles.baseline14,'String'); end
        if (i==4)&&(j==2), textstr=get(handles.baseline24,'String'); end
        if (i==4)&&(j==3), textstr=get(handles.baseline34,'String'); end
        if (i==5)&&(j==1), textstr=get(handles.baseline15,'String'); end
        if (i==5)&&(j==2), textstr=get(handles.baseline25,'String'); end
        if (i==5)&&(j==3), textstr=get(handles.baseline35,'String'); end
        if (i==6)&&(j==1), textstr=get(handles.baseline16,'String'); end
        if (i==6)&&(j==2), textstr=get(handles.baseline26,'String'); end
        if (i==6)&&(j==3), textstr=get(handles.baseline36,'String'); end

        [text_num, status]=str2num(textstr);
        if status==0, mBaseline(i,j)= 0;  else mBaseline(i,j)= text_num; end
    end
end


%% Get the smoothing interval
smoothing_interval=str2num(get(handles.sm_interval,'String'));
if isempty(smoothing_interval) || (smoothing_interval<0),
    smoothing_interval=100;
end
%% Get the total number of epochs to be processed
total_epoch=floor(str2num(get(handles.total_epoch,'String')));
if isempty(total_epoch) || (total_epoch<=0),
    total_epoch=-999; %% -999 means to process all data set
end
%% Get the elevation mask angle for GPS satellite 
maskangle=str2num(get(handles.elev_angle,'String'));
if isempty(maskangle) || (maskangle<10),
    maskangle=10;  
end
%% observation file names, to be recorded
vFileObsNames=get(handles.listbox1,'String');
%% validate the input, at least 3 obs files needed
total_file=length(vFileObsNames);
if total_file<3,
    msgbox('Not sufficient observation files!');
    return
end
%% validate the input, no duplicated input
for i=1:1:total_file-1,
    for j=i+1:1:total_file,
        if strcmp (vFileObsNames{i},vFileObsNames{j}),
            msgbox('Do not input identical data files!');
            return
        end
    end
end

%% Find the number of the valid baseline input
[stop_row,stop_column]=find(mBaseline==0,1); 
total_nonzero=nnz(mBaseline);
num_baseline=stop_row-1;
%% check the number of baselines
if (total_nonzero~=0) && (total_file~=num_baseline), 
        text1=sprintf('Number of baselines does not match the number of antennas! \nNote that attitude can be determined using direct computation approach without the identifications of the baselines. But if you want to specify the baselines, please input all of them.');
        msgbox(text1);
        return     
end
      
total_ant=total_file;
%% rinex navigation file, to be recorded
filenav=get(handles.text_nav,'String');
if length(filenav)==0,
    msgbox('No navigation file!');
    return
end
 
%% Save the data inputted from GUI  
save('DataGUI','vFileObsNames','total_ant','filenav',...
        'smoothing_interval','total_epoch','maskangle','mBaseline','num_baseline','-v6')
%% Analyse the RINEX files
ProcessRINEX();
%% Processing of GPS data to derive attitude parameters
mainpro;
msgbox('Processing successfully finished')
type('results.txt')
 

%% Main program ends here
%%-------------------------------------------------------------------------
%%-------------------------------------------------------------------------
%%-------------------------------------------------------------------------
%%-------------------------------------------------------------------------
 
 
























%% ===========================================
%%      Some initialization function for the control panel
%%                        These can be simply ignored
%% ===========================================


% --- Executes during object creation, after setting all properties.
function baseline12_Callback(hObject, eventdata, handles)

% --- Executes during object creation, after setting all properties.
function baseline12_CreateFcn(hObject, eventdata, handles) 
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


function baseline13_Callback(hObject, eventdata, handles)


% --- Executes during object creation, after setting all properties.
function baseline13_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function baseline23_Callback(hObject, eventdata, handles)


% --- Executes during object creation, after setting all properties.
function baseline23_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function baseline14_Callback(hObject, eventdata, handles)

% --- Executes during object creation, after setting all properties.
function baseline14_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function baseline24_Callback(hObject, eventdata, handles)

% --- Executes during object creation, after setting all properties.
function baseline24_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function baseline34_Callback(hObject, eventdata, handles)

% --- Executes during object creation, after setting all properties.
function baseline34_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function baseline15_Callback(hObject, eventdata, handles)

% --- Executes during object creation, after setting all properties.
function baseline15_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function baseline25_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function baseline25_Callback(hObject, eventdata, handles)

% --- Executes during object creation, after setting all properties.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function baseline35_Callback(hObject, eventdata, handles)
% --- Executes during object creation, after setting all properties.
function baseline35_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function baseline16_Callback(hObject, eventdata, handles)

% --- Executes during object creation, after setting all properties.
function baseline16_CreateFcn(hObject, eventdata, handles)

if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function baseline26_Callback(hObject, eventdata, handles)


% --- Executes during object creation, after setting all properties.
function baseline26_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function baseline36_Callback(hObject, eventdata, handles)

% --- Executes during object creation, after setting all properties.
function baseline36_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


function sm_interval_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function total_epoch_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% --- Executes on selection change in listbox1.
function listbox1_Callback(hObject, eventdata, handles)


% --- Executes during object creation, after setting all properties.
function listbox1_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


 

% --- Outputs from this function are returned to the command line.
function varargout = ControlPanel_OutputFcn(hObject, eventdata, handles)
varargout{1} = handles.output;



function sm_interval_Callback(hObject, eventdata, handles)


function total_epoch_Callback(hObject, eventdata, handles)



function elev_angle_Callback(hObject, eventdata, handles)

% --- Executes during object creation, after setting all properties.
function elev_angle_CreateFcn(hObject, eventdata, handles)

if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end







