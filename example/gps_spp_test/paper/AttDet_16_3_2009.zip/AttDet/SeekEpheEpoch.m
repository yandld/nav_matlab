%%========================================
%%     Toolbox for attitude determination
%%     Zhen Dai
%%     dai@zess.uni-siegen.de
%%     ZESS, University of Siegen, Germany
%%     Last Modified  : 1.Sep.2008
%%========================================
%% Functions:
%%     Search for the proper ephemerides fitting for the given satellite PRN and
%%     the GPS time.
%% Input parameters:
%%      time -> GPS time in "Second of week"
%%      satID -> Satellite PRN
%%      mEphTime(global) -> The starting time of each ephemerides paragraph
%%      mEphemerides(global) -> Ephemerides parameters
%% Output:
%%      eph_epoch -> The proper ephemerides epoch. See following remarks
%% Remarks:
%%      As defined in the RINEX navigation file, the ephemerides are written
%%      in a multiple-paragraph format. Each paragraph start with the
%%      satellite PRN and the time. For each satellite, the ephemerides are
%%      given every 2 hours. For a daily global navigation file, totally 13
%%      paragraphs for each satellite might be provided. In order to obtain
%%      a precise satellite position at a specific time, we have to choose
%%      a proper ephemerides  which closet to the current receipt 
%%      time of GPS measurement.

function eph_epoch=SeekEpheEpoch(time,satID)


global mEphTime mEphemerides

totalrec=size(mEphemerides,2);

findepoch=0;
for i=1:1:totalrec-1,
    %% Find the nearest ephemerides epoch
    diff1=abs(time-mEphTime(satID,i));
    diff2=abs(time-mEphTime(satID,i+1));
    if diff1<diff2,
        epoch=i;
        findepoch=1;
        break;
    end
end
%% Check whether the last ephemerides epoch is suitable for this satellite
if findepoch==0,
    if abs(time-mEphTime(satID,totalrec))<7200,
        epoch=totalrec;
    else
        %% It seems that the observation epoch is out of the range of ephemerides
        error('No proper ehpemeris found!!!!');
    end
end

eph_epoch=epoch;